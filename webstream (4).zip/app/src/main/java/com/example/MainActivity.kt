package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import java.io.File
import java.io.FileOutputStream
import java.net.URL

class MainActivity : ComponentActivity() {
  @OptIn(ExperimentalPermissionsApi::class)
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val permissionsState = rememberMultiplePermissionsState(
            permissions = listOf(
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.RECORD_AUDIO
            )
        )

        LaunchedEffect(Unit) {
            permissionsState.launchMultiplePermissionRequest()
        }

        if (permissionsState.allPermissionsGranted) {
          WebViewScreen(
            modifier = Modifier.fillMaxSize()
          )
        } else {
           Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
               Text("Camera and Microphone permissions are required.")
           }
        }
      }
    }
  }
}

class WebAppInterface(private val context: Context) {
    @JavascriptInterface
    fun downloadFile(url: String, fileName: String) {
        Thread {
            try {
                val input = URL(url).openStream()
                val file = File(context.filesDir, fileName)
                val output = FileOutputStream(file)
                input.copyTo(output)
                output.close()
                input.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(modifier: Modifier = Modifier) {
  AndroidView(
    modifier = modifier,
    factory = { context ->
      WebView(context).apply {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        
        webViewClient = WebViewClient()
        webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                val resources = request.resources
                val grantedResources = mutableListOf<String>()
                if (resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                    grantedResources.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                }
                if (resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                    grantedResources.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                }
                if (grantedResources.isNotEmpty()) {
                    request.grant(grantedResources.toTypedArray())
                } else {
                    request.deny()
                }
            }
        }
        
        val intentUrl = (context as? ComponentActivity)?.intent?.dataString
        val urlToLoad = if (intentUrl != null && intentUrl.startsWith("http://207.231.111.212")) {
            intentUrl
        } else {
            "http://207.231.111.212/"
        }
        
        addJavascriptInterface(WebAppInterface(context), "AndroidInterface")
        loadUrl(urlToLoad)
      }
    }
  )
}
